package com.ibm.dev;


class Currency {
	
	private String symbol;
	private String requestDt;
	private double open;
	private double close;
	private double low;
	private double high;

	public Currency() {
		// TODO Auto-generated constructor stub
	}
	
	public Currency(String symbol, String requestDt, double open, double close, double low, double high) {
		
		this.symbol = symbol;
		this.requestDt = requestDt;
		this.open = open;
		this.close = close;
		this.low = low;
		this.high = high;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getRequestDt() {
		return requestDt;
	}

	public void setRequestDt(String requestDt) {
		this.requestDt = requestDt;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(Double open) {
		this.open = open;
	}

	public double getClose() {
		return close;
	}

	public void setClose(Double close) {
		this.close = close;
	}

	public double getLow() {
		return low;
	}

	public void setLow(Double low) {
		this.low = low;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(Double high) {
		this.high = high;
	}

}
