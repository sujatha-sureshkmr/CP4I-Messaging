package com.ibm.dev;

import java.util.ArrayList;

public final class Currencies {
	
	private static ArrayList<Currency> currencyList = new ArrayList<Currency>();
	
	static {
		
		currencyList.add(new Currency("EURUSD", "2019-10-09", 1.09807, 1.09802, 1.09798, 1.09816));
		currencyList.add(new Currency("USDJPY", "2019-10-09", 107.354, 107.34929, 107.34328, 107.35429));
		currencyList.add(new Currency("AUDUSD", "2019-10-09", 0.67446, 0.67446, 0.67443, 0.6745));
		currencyList.add(new Currency("SGDUSD", "2019-10-09", 0.72437, 0.7244, 0.72445, 0.72437));
		currencyList.add(new Currency("GBPEUR", "2019-10-09", 1.11324, 1.11314, 1.11326, 1.11305));
		currencyList.add(new Currency("PHPEUR", "2019-10-09", 0.01758, 0.01758, 0.01758, 0.01758));
		
	}

	private Currencies() {
		
	}
	
	public static ArrayList<Currency> getCurrencies() {
		
		return currencyList;
	}

}