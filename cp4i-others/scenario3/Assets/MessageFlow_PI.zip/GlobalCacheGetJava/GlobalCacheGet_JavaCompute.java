import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;


public class GlobalCacheGet_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new output message as a copy of the input
			
			MbMessage outMessage = new MbMessage();
			MbElement outRoot = outMessage.getRootElement();

			// Input message 
			
			//Make a modifiable MbMessage based on the input message passed in on the inAssembly.
			MbMessage clonedInMessage = new MbMessage(inAssembly.getMessage());
			MbElement inputRootElement = clonedInMessage.getRootElement();
						
		//	MbElement inputXMLNSCRoot = inputRootElement.getLastChild(); //gets the message element
		//	MbElement currentInput = inputXMLNSCRoot.getFirstChild(); // gets the first element in the message 
			
		//	MbElement MapName = currentInput.getFirstElementByPath("name");
		//	String strMapName = MapName.getValueAsString(); //gets the map name 
			String strMapName = "testmap";
			//creates a new map or gets the existing map 	
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(strMapName); 
			
			String message = "Map Read Successfully" ;
			
						
			//new code 
			//MbElement elmEntry= MapName.getNextSibling();
					
			//String strKey = elmEntry.getFirstChild().getName();
			//String strValue = (String) elmEntry.getFirstChild().getValue();
			
			 String strValue =  "value1";
				String strKey = "key1";
			// to retrive the map data 
            String myMsg = String.valueOf(globalMap.get(strKey));
		  
		    // Create the Broker Blob Parser element
			 MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
			 // Create the BLOB element in the Blob parser domain with the required text
			 MbElement outBody = outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", myMsg.getBytes());  	 							  	
				
	          outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}
}

